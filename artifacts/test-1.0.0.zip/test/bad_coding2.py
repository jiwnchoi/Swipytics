﻿#coding: utf8
print('我')
