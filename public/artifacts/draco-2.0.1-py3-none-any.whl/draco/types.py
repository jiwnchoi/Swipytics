from typing import Iterable, TypeAlias

Specification: TypeAlias = Iterable[str] | str
